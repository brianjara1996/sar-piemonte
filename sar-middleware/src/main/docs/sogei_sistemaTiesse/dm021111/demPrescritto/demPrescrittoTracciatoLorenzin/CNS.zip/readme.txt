Certificato di test per l'autenticazione come da CNS.
E' un certificato del tutto simile a quelli caricati sulle CNS, e serve per eseguire le prove di autenticazione nell'ambiente di test.
Nel certificato � contenuto il codice fiscale del medico di test: PROVAX00X00X000Y.
Il certificato va rinominato in .p12 .
La password �: 1234
